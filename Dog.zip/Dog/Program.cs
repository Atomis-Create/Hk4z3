﻿/*
Hunter Krause
16146144
2/14/2020
Challenge: Dog
Info 2040
*/

using System;
public enum Gender
{
    Male,
    Female
}

namespace Dog
{
    public class Dog
    { 
        public string name;
        public string owner;
        public int age;
        public Gender gender;
        public Dog(string name, string owner, int age, Gender gender)
         {
            this.name = name;
            this.owner = owner;
            this.age = age;
            this.gender = gender;
         }

        public void Bark(int count)
        {
            int i;
            for (i = 0; i <count; i++)
            {
                Console.WriteLine("Woof!");
            }

        }


    public string GetTag()
        {
            string pronoun1 = "", pronoun2 = "";
            if (gender == Gender.Male)
            {
                pronoun1 = "His";
                pronoun2 = "he";
            }
            if (gender == Gender.Female)
            {
                pronoun1 = "Her";
                pronoun2 = "she";
            }

            string ageMod;
            if (age > 1)
                ageMod="years";
            else
                ageMod="year";

            string s = String.Format("If Lost, call {0}. {1} name is {2} and {3} is {4} {5} old.", owner, pronoun1, name, pronoun2, age, ageMod);
            return s;
        }
     public class Program
        {
            static void Main(string[] args)
            {
                var puppy = new Dog("Orion", "Shawn", 1, Gender.Male);
                puppy.Bark(3);
                Console.WriteLine(puppy.GetTag());

                var myDog = new Dog("Lilei", "Dale", 4, Gender.Female);
                myDog.Bark(1);
                Console.WriteLine(myDog.GetTag());

                var huntDog = new Dog("Goose", "Hunter+Kat", 1, Gender.Female);
                huntDog.Bark(4);
                Console.WriteLine(huntDog.GetTag());
            }

        }

    }



 
}